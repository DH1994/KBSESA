#ifndef GameField_h
#define GameField_h

#include <MI0283QT9.h>
#include "Player.h"

class GameField {
	public:
		GameField(MI0283QT9 lcd_g, uint8_t game_g, Player &playerNC_g);
		int getFieldValue(uint8_t x, uint8_t y);
		void updateGameField();
	private:
		uint8_t activeField[9][11];
		MI0283QT9 lcd;
		Player *playerNC, *playerIR;
};
#endif
