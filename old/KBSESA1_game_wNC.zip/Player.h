#ifndef Player_h
#define Player_h

#include "NunchukLibrary.h"
#include "GameField.h"

class Player{
	public:
		Player(NunchukLibrary &NC_g);
		void setPosition(uint8_t xPos_g, uint8_t yPos_g);
		void setGameField(GameField &gameField);
		bool updatePlayer();
		uint8_t getBlockResetX();
		uint8_t getBlockResetY();
		bool getBlockResetOffsetX();
		bool getBlockResetOffsetY();
		int getxPos();
		int getyPos();
	private:
		NunchukLibrary *NC;
		GameField *gameField;
		uint8_t blockReset[2][2];
		uint8_t xPos, yPos;				//are the pixel coordinates of the topleft corner of the player
		uint8_t xStep, yStep;			//are the steps offset from xPos and yPos
		uint8_t stepsize;
};

#endif