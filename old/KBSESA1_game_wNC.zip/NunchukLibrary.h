#ifndef NunchukLibrary_h
#define NunchukLibrary_h

class NunchukLibrary {
public:
    void AN_sendByte(uint8_t data, uint8_t location);
    void NunchukLoop();
    void ANinit();
    void ANupdate();
	void UpdateLocation();
	
    int zButton;
    int cButton;
	//uint8_t status;
	enum status{
		n_IDLE = 0,
		n_LEFT = 1,
		n_RIGHT = 2,
		n_UP = 3,
		n_DOWN = 4,
	};
	
private:
    int analogX;
    int analogY;
    int accelX;
    int accelY;
    int accelZ;
	int beginPossX;
	int beginPossY;
};
#endif