#include "Player.h"
#include "gameField.h"
#include "arduino.h"
#include "NunchukLibrary.h"
#define SIZE 24

GameField *gameField;

Player::Player(NunchukLibrary *NC_g){
	NC = NC_g;
}
void Player::setPosition(uint8_t xPos_g, uint8_t yPos_g){
	xPos = xPos_g;
	yPos = yPos_g;
	xStep = 0;
	yStep = 0;
	stepsize = 3;
}

void Player::setGameField(GameField *gameField_g){
	gameField = gameField_g;
}

bool Player::updatePlayer(){
	
	blockReset[0][0] = xPos;
	blockReset[0][1] = yPos;
	blockReset[1][0] = (xStep) ? (xPos + 1) : (xPos);
	blockReset[1][1] = (yStep) ? (yPos + 1) : (yPos);

	bool returnbool = false;

	switch (NC->status)
	{
		case NC->status.n_UP:
			if((xStep == 0)){			//checks if their is an ability to move up or down because of the offset on the other axis
				if(yStep == 0){
					if(!((gameField->getFieldValue(xPos, yPos - 1) == 1) || (gameField->getFieldValue(xPos, yPos - 1) == 2))){
						yPos--;
						yStep = SIZE - stepsize;
						returnbool = true;
					}
				} else {
					yStep -= stepsize;
					returnbool = true;
				}
			}
		break;

		case NC->status.n_DOWN:
			if((xStep == 0)){			//checks if their is an ability to move up or down because of the offset on the other axis
				if(yStep == 0){
					if(!((gameField->getFieldValue(xPos, yPos + 1) == 1) || (gameField->getFieldValue(xPos, yPos + 1) == 2))){
						yStep += stepsize;
						returnbool = true;
					}
				} else {
					if ((yStep + stepsize) == 24) {
						yPos++;
						yStep = 0;
						returnbool = true;
					} else {
						yStep += stepsize;
						returnbool = true;
					}
				}
			}
		break;

		case NC->status.n_LEFT:
			if(yStep == 0){
				if((xStep == 0)){
					if(!((gameField->getFieldValue(xPos - 1, yPos) == 1) || (gameField->getFieldValue(xPos - 1, yPos) == 2))){
						xPos--;
						xStep = SIZE - stepsize;
						returnbool = true;
					}
				} else {
					xStep -= stepsize;
					returnbool = true;
				}
			}
		break;

		case NC->status.n_RIGHT:
			if(yStep == 0){
				if((xStep == 0)){
					if(!((gameField->getFieldValue(xPos + 1, yPos) == 1) || (gameField->getFieldValue(xPos + 1, yPos) == 2))){
						xStep += stepsize;
						returnbool = true;
					}
				} else {
					if ((xStep + stepsize) == 24) {
						xPos++;
						xStep = 0;
						returnbool = true;
					} else {
						xStep += stepsize;
						returnbool = true;
					}
				}
			}
		break;
		return returnbool;
	}	
}

uint8_t Player::getBlockResetX(){
	return blockReset[0][0];
}
uint8_t Player::getBlockResetY(){
	return blockReset[0][1];
}
bool Player::getBlockResetOffsetX(){
	return (blockReset[0][0] > blockReset[1][0]) ? (true) : (false);
}
bool Player::getBlockResetOffsetY(){
	return (blockReset[0][1] > blockReset[1][1]) ? (true) : (false);
}
int Player::getxPos(){
	return xPos * SIZE + xStep;
}
int Player::getyPos(){
	return yPos * SIZE + yStep;
}



